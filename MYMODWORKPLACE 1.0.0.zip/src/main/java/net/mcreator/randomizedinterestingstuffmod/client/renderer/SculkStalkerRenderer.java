
package net.mcreator.randomizedinterestingstuffmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.randomizedinterestingstuffmod.entity.SculkStalkerEntity;
import net.mcreator.randomizedinterestingstuffmod.client.model.Modelcustom_model;

public class SculkStalkerRenderer extends MobRenderer<SculkStalkerEntity, Modelcustom_model<SculkStalkerEntity>> {
	public SculkStalkerRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcustom_model(context.bakeLayer(Modelcustom_model.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SculkStalkerEntity entity) {
		return new ResourceLocation("randomized_interesting_stuff_mod:textures/entities/sculk_enderman_1_stalker.png");
	}
}
