
package net.mcreator.randomizedinterestingstuffmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SilverfishModel;

import net.mcreator.randomizedinterestingstuffmod.entity.SculkBeetleEntity;

public class SculkBeetleRenderer extends MobRenderer<SculkBeetleEntity, SilverfishModel<SculkBeetleEntity>> {
	public SculkBeetleRenderer(EntityRendererProvider.Context context) {
		super(context, new SilverfishModel(context.bakeLayer(ModelLayers.SILVERFISH)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SculkBeetleEntity entity) {
		return new ResourceLocation("randomized_interesting_stuff_mod:textures/entities/sculk_silverfish_2_beetle.png");
	}
}
