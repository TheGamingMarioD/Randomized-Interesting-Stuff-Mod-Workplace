
package net.mcreator.randomizedinterestingstuffmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;

import net.mcreator.randomizedinterestingstuffmod.entity.SculkCreeperEntity;

public class SculkCreeperRenderer extends MobRenderer<SculkCreeperEntity, CreeperModel<SculkCreeperEntity>> {
	public SculkCreeperRenderer(EntityRendererProvider.Context context) {
		super(context, new CreeperModel(context.bakeLayer(ModelLayers.CREEPER)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SculkCreeperEntity entity) {
		return new ResourceLocation("randomized_interesting_stuff_mod:textures/entities/sculk_creeper_2.png");
	}
}
