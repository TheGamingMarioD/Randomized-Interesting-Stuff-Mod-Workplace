
package net.mcreator.randomizedinterestingstuffmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModFluids;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModFluidTypes;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModBlocks;

public abstract class DeepDarkMudFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(
			() -> RandomizedInterestingStuffModModFluidTypes.DEEP_DARK_MUD_TYPE.get(),
			() -> RandomizedInterestingStuffModModFluids.DEEP_DARK_MUD.get(),
			() -> RandomizedInterestingStuffModModFluids.FLOWING_DEEP_DARK_MUD.get()).explosionResistance(100f).slopeFindDistance(3)
			.bucket(() -> RandomizedInterestingStuffModModItems.DEEP_DARK_MUD_BUCKET.get())
			.block(() -> (LiquidBlock) RandomizedInterestingStuffModModBlocks.DEEP_DARK_MUD.get());

	private DeepDarkMudFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.SCULK_SOUL;
	}

	public static class Source extends DeepDarkMudFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends DeepDarkMudFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
