
package net.mcreator.randomizedinterestingstuffmod.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.randomizedinterestingstuffmod.procedures.AncientProtectionOnEffectActiveTickProcedure;

public class AncientProtectionMobEffect extends MobEffect {
	public AncientProtectionMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -16775886);
	}

	@Override
	public String getDescriptionId() {
		return "effect.randomized_interesting_stuff_mod.ancient_protection";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		AncientProtectionOnEffectActiveTickProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
