
package net.mcreator.randomizedinterestingstuffmod.potion;

import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.randomizedinterestingstuffmod.procedures.AdrenalineRushPotionEffectOnEffectActiveTickProcedure;
import net.mcreator.randomizedinterestingstuffmod.procedures.AdrenalineRushPotionEffectEffectStartedappliedProcedure;

public class AdrenalineRushPotionEffectMobEffect extends MobEffect {
	public AdrenalineRushPotionEffectMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -6681074);
	}

	@Override
	public String getDescriptionId() {
		return "effect.randomized_interesting_stuff_mod.adrenaline_rush_potion_effect";
	}

	@Override
	public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		AdrenalineRushPotionEffectEffectStartedappliedProcedure.execute(entity);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		AdrenalineRushPotionEffectOnEffectActiveTickProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
