
package net.mcreator.randomizedinterestingstuffmod.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.randomizedinterestingstuffmod.procedures.CustomPoison1OnEffectActiveTickProcedure;
import net.mcreator.randomizedinterestingstuffmod.procedures.CustomPoison1ActiveTickConditionProcedure;

public class CustomPoison1MobEffect extends MobEffect {
	public CustomPoison1MobEffect() {
		super(MobEffectCategory.HARMFUL, -16777165);
	}

	@Override
	public String getDescriptionId() {
		return "effect.randomized_interesting_stuff_mod.custom_poison_1";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		CustomPoison1OnEffectActiveTickProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return CustomPoison1ActiveTickConditionProcedure.execute(amplifier, duration);
	}
}
