
package net.mcreator.randomizedinterestingstuffmod.world.biome;

import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.Music;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.data.worldgen.BiomeDefaultFeatures;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModEntities;

public class SkulkPlainsBiomeBiome {
	public static Biome createBiome() {
		BiomeSpecialEffects effects = new BiomeSpecialEffects.Builder().fogColor(-16507619).waterColor(-16507619).waterFogColor(-16507619)
				.skyColor(-16507619).foliageColorOverride(-16507619).grassColorOverride(-16507619)
				.backgroundMusic(
						new Music(new SoundEvent(new ResourceLocation("randomized_interesting_stuff_mod:deepdarkbiome.music")), 12000, 24000, true))
				.build();
		BiomeGenerationSettings.Builder biomeGenerationSettings = new BiomeGenerationSettings.Builder();
		BiomeDefaultFeatures.addDefaultCarversAndLakes(biomeGenerationSettings);
		BiomeDefaultFeatures.addSculk(biomeGenerationSettings);
		MobSpawnSettings.Builder mobSpawnInfo = new MobSpawnSettings.Builder();
		mobSpawnInfo.addSpawn(MobCategory.MONSTER, new MobSpawnSettings.SpawnerData(EntityType.WARDEN, 4, 1, 1));
		mobSpawnInfo.addSpawn(MobCategory.MONSTER,
				new MobSpawnSettings.SpawnerData(RandomizedInterestingStuffModModEntities.SCULK_ANT_MOD.get(), 15, 4, 6));
		mobSpawnInfo.addSpawn(MobCategory.MONSTER,
				new MobSpawnSettings.SpawnerData(RandomizedInterestingStuffModModEntities.SCULK_CORPSE_WALKER.get(), 5, 2, 3));
		mobSpawnInfo.addSpawn(MobCategory.MONSTER,
				new MobSpawnSettings.SpawnerData(RandomizedInterestingStuffModModEntities.SCULK_CREEPER.get(), 5, 1, 2));
		mobSpawnInfo.addSpawn(MobCategory.MONSTER,
				new MobSpawnSettings.SpawnerData(RandomizedInterestingStuffModModEntities.SCULK_SPIDER.get(), 5, 1, 2));
		mobSpawnInfo.addSpawn(MobCategory.MONSTER,
				new MobSpawnSettings.SpawnerData(RandomizedInterestingStuffModModEntities.SCULK_BEETLE.get(), 20, 4, 4));
		return new Biome.BiomeBuilder().precipitation(Biome.Precipitation.NONE).temperature(-1f).downfall(0f).specialEffects(effects)
				.mobSpawnSettings(mobSpawnInfo.build()).generationSettings(biomeGenerationSettings.build()).build();
	}
}
