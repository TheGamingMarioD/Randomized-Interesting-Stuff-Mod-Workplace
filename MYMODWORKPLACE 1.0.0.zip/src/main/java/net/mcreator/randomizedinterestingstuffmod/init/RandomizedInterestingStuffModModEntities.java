
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.randomizedinterestingstuffmod.entity.SculkStalkerEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.SculkSpiderEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.SculkCreeperEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.SculkCorpseWalkerEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.SculkBeetleEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.SculkAntModEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.CustomrangeditemEntity;
import net.mcreator.randomizedinterestingstuffmod.entity.AncientBowExplosiveEntity;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RandomizedInterestingStuffModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<EntityType<CustomrangeditemEntity>> CUSTOMRANGEDITEM = register("projectile_customrangeditem",
			EntityType.Builder.<CustomrangeditemEntity>of(CustomrangeditemEntity::new, MobCategory.MISC)
					.setCustomClientFactory(CustomrangeditemEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<AncientBowExplosiveEntity>> ANCIENT_BOW_EXPLOSIVE = register("projectile_ancient_bow_explosive",
			EntityType.Builder.<AncientBowExplosiveEntity>of(AncientBowExplosiveEntity::new, MobCategory.MISC)
					.setCustomClientFactory(AncientBowExplosiveEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SculkAntModEntity>> SCULK_ANT_MOD = register("sculk_ant_mod",
			EntityType.Builder.<SculkAntModEntity>of(SculkAntModEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkAntModEntity::new).fireImmune().sized(0.4f, 0.3f));
	public static final RegistryObject<EntityType<SculkSpiderEntity>> SCULK_SPIDER = register("sculk_spider",
			EntityType.Builder.<SculkSpiderEntity>of(SculkSpiderEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkSpiderEntity::new).fireImmune().sized(1.4f, 0.9f));
	public static final RegistryObject<EntityType<SculkCorpseWalkerEntity>> SCULK_CORPSE_WALKER = register("sculk_corpse_walker",
			EntityType.Builder.<SculkCorpseWalkerEntity>of(SculkCorpseWalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkCorpseWalkerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SculkCreeperEntity>> SCULK_CREEPER = register("sculk_creeper",
			EntityType.Builder.<SculkCreeperEntity>of(SculkCreeperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkCreeperEntity::new).fireImmune().sized(0.6f, 1.7f));
	public static final RegistryObject<EntityType<SculkStalkerEntity>> SCULK_STALKER = register("sculk_stalker",
			EntityType.Builder.<SculkStalkerEntity>of(SculkStalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkStalkerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SculkBeetleEntity>> SCULK_BEETLE = register("sculk_beetle",
			EntityType.Builder.<SculkBeetleEntity>of(SculkBeetleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SculkBeetleEntity::new).fireImmune().sized(0.4f, 0.3f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SculkAntModEntity.init();
			SculkSpiderEntity.init();
			SculkCorpseWalkerEntity.init();
			SculkCreeperEntity.init();
			SculkStalkerEntity.init();
			SculkBeetleEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SCULK_ANT_MOD.get(), SculkAntModEntity.createAttributes().build());
		event.put(SCULK_SPIDER.get(), SculkSpiderEntity.createAttributes().build());
		event.put(SCULK_CORPSE_WALKER.get(), SculkCorpseWalkerEntity.createAttributes().build());
		event.put(SCULK_CREEPER.get(), SculkCreeperEntity.createAttributes().build());
		event.put(SCULK_STALKER.get(), SculkStalkerEntity.createAttributes().build());
		event.put(SCULK_BEETLE.get(), SculkBeetleEntity.createAttributes().build());
	}
}
