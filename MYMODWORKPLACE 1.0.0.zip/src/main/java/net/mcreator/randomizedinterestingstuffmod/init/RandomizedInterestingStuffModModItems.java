
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.randomizedinterestingstuffmod.item.WardenHeartItem;
import net.mcreator.randomizedinterestingstuffmod.item.SteelItem;
import net.mcreator.randomizedinterestingstuffmod.item.GraphiteDustItem;
import net.mcreator.randomizedinterestingstuffmod.item.EchoIngotItem;
import net.mcreator.randomizedinterestingstuffmod.item.DeepDarkMudItem;
import net.mcreator.randomizedinterestingstuffmod.item.DeepDarkDimensionItem;
import net.mcreator.randomizedinterestingstuffmod.item.CustomrangeditemItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonSteelArmorItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonReinforcedSwordItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonReinforcedShovelItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonReinforcedPickaxeItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonReinforcedHoeItem;
import net.mcreator.randomizedinterestingstuffmod.item.CarbonReinforcedAxeItem;
import net.mcreator.randomizedinterestingstuffmod.item.AncientBowExplosiveItem;
import net.mcreator.randomizedinterestingstuffmod.item.AncientArmorItem;
import net.mcreator.randomizedinterestingstuffmod.item.AlluahAkbarArmourItem;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<Item> MAPLE_WOOD = block(RandomizedInterestingStuffModModBlocks.MAPLE_WOOD,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAPLE_LOG = block(RandomizedInterestingStuffModModBlocks.MAPLE_LOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAPLE_PLANKS = block(RandomizedInterestingStuffModModBlocks.MAPLE_PLANKS,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAPLE_LEAVES = block(RandomizedInterestingStuffModModBlocks.MAPLE_LEAVES,
			CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> MAPLE_STAIRS = block(RandomizedInterestingStuffModModBlocks.MAPLE_STAIRS,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAPLE_SLAB = block(RandomizedInterestingStuffModModBlocks.MAPLE_SLAB,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAPLE_FENCE = block(RandomizedInterestingStuffModModBlocks.MAPLE_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> MAPLE_FENCE_GATE = block(RandomizedInterestingStuffModModBlocks.MAPLE_FENCE_GATE,
			CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> MAPLE_PRESSURE_PLATE = block(RandomizedInterestingStuffModModBlocks.MAPLE_PRESSURE_PLATE,
			CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> MAPLE_BUTTON = block(RandomizedInterestingStuffModModBlocks.MAPLE_BUTTON,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ANCIENT_ARMOR_HELMET = REGISTRY.register("ancient_armor_helmet", () -> new AncientArmorItem.Helmet());
	public static final RegistryObject<Item> ANCIENT_ARMOR_CHESTPLATE = REGISTRY.register("ancient_armor_chestplate",
			() -> new AncientArmorItem.Chestplate());
	public static final RegistryObject<Item> ANCIENT_ARMOR_LEGGINGS = REGISTRY.register("ancient_armor_leggings",
			() -> new AncientArmorItem.Leggings());
	public static final RegistryObject<Item> ANCIENT_ARMOR_BOOTS = REGISTRY.register("ancient_armor_boots", () -> new AncientArmorItem.Boots());
	public static final RegistryObject<Item> CUSTOMRANGEDITEM = REGISTRY.register("customrangeditem", () -> new CustomrangeditemItem());
	public static final RegistryObject<Item> GRAPHITE_DUST = REGISTRY.register("graphite_dust", () -> new GraphiteDustItem());
	public static final RegistryObject<Item> GRAPHITE_ORE = block(RandomizedInterestingStuffModModBlocks.GRAPHITE_ORE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> GRAPHITE_BLOCK = block(RandomizedInterestingStuffModModBlocks.GRAPHITE_BLOCK,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> STEEL = REGISTRY.register("steel", () -> new SteelItem());
	public static final RegistryObject<Item> CARBON_STEEL_ARMOR_HELMET = REGISTRY.register("carbon_steel_armor_helmet",
			() -> new CarbonSteelArmorItem.Helmet());
	public static final RegistryObject<Item> CARBON_STEEL_ARMOR_CHESTPLATE = REGISTRY.register("carbon_steel_armor_chestplate",
			() -> new CarbonSteelArmorItem.Chestplate());
	public static final RegistryObject<Item> CARBON_STEEL_ARMOR_LEGGINGS = REGISTRY.register("carbon_steel_armor_leggings",
			() -> new CarbonSteelArmorItem.Leggings());
	public static final RegistryObject<Item> CARBON_STEEL_ARMOR_BOOTS = REGISTRY.register("carbon_steel_armor_boots",
			() -> new CarbonSteelArmorItem.Boots());
	public static final RegistryObject<Item> ALLOY_FURNACE = block(RandomizedInterestingStuffModModBlocks.ALLOY_FURNACE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ECHO_INGOT = REGISTRY.register("echo_ingot", () -> new EchoIngotItem());
	public static final RegistryObject<Item> ANCIENT_BOW_EXPLOSIVE = REGISTRY.register("ancient_bow_explosive", () -> new AncientBowExplosiveItem());
	public static final RegistryObject<Item> ALLUAH_AKBAR_ARMOUR_CHESTPLATE = REGISTRY.register("alluah_akbar_armour_chestplate",
			() -> new AlluahAkbarArmourItem.Chestplate());
	public static final RegistryObject<Item> WARDEN_HEART = REGISTRY.register("warden_heart", () -> new WardenHeartItem());
	public static final RegistryObject<Item> DEEP_DARK_DIMENSION = REGISTRY.register("deep_dark_dimension", () -> new DeepDarkDimensionItem());
	public static final RegistryObject<Item> DEEP_DARK_MUD_BUCKET = REGISTRY.register("deep_dark_mud_bucket", () -> new DeepDarkMudItem());
	public static final RegistryObject<Item> CARBON_REINFORCED_PICKAXE = REGISTRY.register("carbon_reinforced_pickaxe",
			() -> new CarbonReinforcedPickaxeItem());
	public static final RegistryObject<Item> CARBON_REINFORCED_AXE = REGISTRY.register("carbon_reinforced_axe", () -> new CarbonReinforcedAxeItem());
	public static final RegistryObject<Item> CARBON_REINFORCED_SWORD = REGISTRY.register("carbon_reinforced_sword",
			() -> new CarbonReinforcedSwordItem());
	public static final RegistryObject<Item> CARBON_REINFORCED_SHOVEL = REGISTRY.register("carbon_reinforced_shovel",
			() -> new CarbonReinforcedShovelItem());
	public static final RegistryObject<Item> CARBON_REINFORCED_HOE = REGISTRY.register("carbon_reinforced_hoe", () -> new CarbonReinforcedHoeItem());
	public static final RegistryObject<Item> SCULK_ANT_MOD = REGISTRY.register("sculk_ant_mod_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_ANT_MOD, -16764109, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCULK_SPIDER = REGISTRY.register("sculk_spider_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_SPIDER, -13421569, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCULK_CORPSE_WALKER = REGISTRY.register("sculk_corpse_walker_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_CORPSE_WALKER, -16764109, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCULK_CREEPER = REGISTRY.register("sculk_creeper_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_CREEPER, -16777165, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCULK_STALKER = REGISTRY.register("sculk_stalker_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_STALKER, -16764109, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCULK_BEETLE = REGISTRY.register("sculk_beetle_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomizedInterestingStuffModModEntities.SCULK_BEETLE, -16764109, -52,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
