
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.randomizedinterestingstuffmod.world.features.ores.GraphiteOreFeature;
import net.mcreator.randomizedinterestingstuffmod.world.features.lakes.DeepDarkMudFeature;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

@Mod.EventBusSubscriber
public class RandomizedInterestingStuffModModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<Feature<?>> GRAPHITE_ORE = REGISTRY.register("graphite_ore", GraphiteOreFeature::feature);
	public static final RegistryObject<Feature<?>> DEEP_DARK_MUD = REGISTRY.register("deep_dark_mud", DeepDarkMudFeature::feature);
}
