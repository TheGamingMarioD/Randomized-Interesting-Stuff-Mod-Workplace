
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.randomizedinterestingstuffmod.network.MechanicalbootsjetpackprocedurekeybindMessage;
import net.mcreator.randomizedinterestingstuffmod.network.CustomAdrenalineRushMessage;
import net.mcreator.randomizedinterestingstuffmod.network.ALLUAHAKBARKEYBINDMessage;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class RandomizedInterestingStuffModModKeyMappings {
	public static final KeyMapping CUSTOM_ADRENALINE_RUSH = new KeyMapping("key.randomized_interesting_stuff_mod.custom_adrenaline_rush",
			GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.movement") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				RandomizedInterestingStuffModMod.PACKET_HANDLER.sendToServer(new CustomAdrenalineRushMessage(0, 0));
				CustomAdrenalineRushMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping MECHANICALBOOTSJETPACKPROCEDUREKEYBIND = new KeyMapping(
			"key.randomized_interesting_stuff_mod.mechanicalbootsjetpackprocedurekeybind", GLFW.GLFW_KEY_N, "key.categories.movement") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				RandomizedInterestingStuffModMod.PACKET_HANDLER.sendToServer(new MechanicalbootsjetpackprocedurekeybindMessage(0, 0));
				MechanicalbootsjetpackprocedurekeybindMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping ALLUAHAKBARKEYBIND = new KeyMapping("key.randomized_interesting_stuff_mod.alluahakbarkeybind", GLFW.GLFW_KEY_H,
			"key.categories.movement") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				RandomizedInterestingStuffModMod.PACKET_HANDLER.sendToServer(new ALLUAHAKBARKEYBINDMessage(0, 0));
				ALLUAHAKBARKEYBINDMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(CUSTOM_ADRENALINE_RUSH);
		event.register(MECHANICALBOOTSJETPACKPROCEDUREKEYBIND);
		event.register(ALLUAHAKBARKEYBIND);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (Minecraft.getInstance().screen == null) {
				CUSTOM_ADRENALINE_RUSH.consumeClick();
				MECHANICALBOOTSJETPACKPROCEDUREKEYBIND.consumeClick();
				ALLUAHAKBARKEYBIND.consumeClick();
			}
		}
	}
}
