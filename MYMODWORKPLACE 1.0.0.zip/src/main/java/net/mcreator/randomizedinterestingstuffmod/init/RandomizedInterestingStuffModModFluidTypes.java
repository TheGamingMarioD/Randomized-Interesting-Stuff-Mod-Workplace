
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.randomizedinterestingstuffmod.fluid.types.DeepDarkMudFluidType;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<FluidType> DEEP_DARK_MUD_TYPE = REGISTRY.register("deep_dark_mud", () -> new DeepDarkMudFluidType());
}
