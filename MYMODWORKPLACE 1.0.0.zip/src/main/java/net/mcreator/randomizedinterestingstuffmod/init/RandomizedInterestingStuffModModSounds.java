
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<SoundEvent> DEEPDARKBIOME_MUSIC = REGISTRY.register("deepdarkbiome.music",
			() -> new SoundEvent(new ResourceLocation("randomized_interesting_stuff_mod", "deepdarkbiome.music")));
}
