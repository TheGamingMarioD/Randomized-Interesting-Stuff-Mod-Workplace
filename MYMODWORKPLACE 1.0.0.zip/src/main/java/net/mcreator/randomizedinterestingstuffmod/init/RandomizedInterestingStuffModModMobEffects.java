
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.randomizedinterestingstuffmod.potion.LastLaughSeriumMobEffect;
import net.mcreator.randomizedinterestingstuffmod.potion.CustomPoison1MobEffect;
import net.mcreator.randomizedinterestingstuffmod.potion.AncientProtectionMobEffect;
import net.mcreator.randomizedinterestingstuffmod.potion.AdrenalineRushPotionEffectMobEffect;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<MobEffect> ADRENALINE_RUSH_POTION_EFFECT = REGISTRY.register("adrenaline_rush_potion_effect",
			() -> new AdrenalineRushPotionEffectMobEffect());
	public static final RegistryObject<MobEffect> CUSTOM_POISON_1 = REGISTRY.register("custom_poison_1", () -> new CustomPoison1MobEffect());
	public static final RegistryObject<MobEffect> LAST_LAUGH_SERIUM = REGISTRY.register("last_laugh_serium", () -> new LastLaughSeriumMobEffect());
	public static final RegistryObject<MobEffect> ANCIENT_PROTECTION = REGISTRY.register("ancient_protection",
			() -> new AncientProtectionMobEffect());
}
