
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<Potion> MYSTERIOUS_CONCOCTION = REGISTRY.register("mysterious_concoction",
			() -> new Potion(new MobEffectInstance(RandomizedInterestingStuffModModMobEffects.CUSTOM_POISON_1.get(), 160, 0, false, true)));
}
