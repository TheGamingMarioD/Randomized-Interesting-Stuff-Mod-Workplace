
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkStalkerRenderer;
import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkSpiderRenderer;
import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkCreeperRenderer;
import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkCorpseWalkerRenderer;
import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkBeetleRenderer;
import net.mcreator.randomizedinterestingstuffmod.client.renderer.SculkAntModRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RandomizedInterestingStuffModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.CUSTOMRANGEDITEM.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.ANCIENT_BOW_EXPLOSIVE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_ANT_MOD.get(), SculkAntModRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_SPIDER.get(), SculkSpiderRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_CORPSE_WALKER.get(), SculkCorpseWalkerRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_CREEPER.get(), SculkCreeperRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_STALKER.get(), SculkStalkerRenderer::new);
		event.registerEntityRenderer(RandomizedInterestingStuffModModEntities.SCULK_BEETLE.get(), SculkBeetleRenderer::new);
	}
}
