
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.randomizedinterestingstuffmod.fluid.DeepDarkMudFluid;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<FlowingFluid> DEEP_DARK_MUD = REGISTRY.register("deep_dark_mud", () -> new DeepDarkMudFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_DEEP_DARK_MUD = REGISTRY.register("flowing_deep_dark_mud",
			() -> new DeepDarkMudFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(DEEP_DARK_MUD.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_DEEP_DARK_MUD.get(), RenderType.translucent());
		}
	}
}
