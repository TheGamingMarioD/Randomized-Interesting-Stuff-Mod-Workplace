
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.randomizedinterestingstuffmod.world.inventory.AlloyFurnaceGuiMenu;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

public class RandomizedInterestingStuffModModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES,
			RandomizedInterestingStuffModMod.MODID);
	public static final RegistryObject<MenuType<AlloyFurnaceGuiMenu>> ALLOY_FURNACE_GUI = REGISTRY.register("alloy_furnace_gui",
			() -> IForgeMenuType.create(AlloyFurnaceGuiMenu::new));
}
