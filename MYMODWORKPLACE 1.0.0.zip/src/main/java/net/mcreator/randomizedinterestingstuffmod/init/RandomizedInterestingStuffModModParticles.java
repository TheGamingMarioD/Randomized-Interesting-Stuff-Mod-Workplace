
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomizedinterestingstuffmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.randomizedinterestingstuffmod.client.particle.MapleTreeLeavesFallingParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RandomizedInterestingStuffModModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.register(RandomizedInterestingStuffModModParticleTypes.MAPLE_TREE_LEAVES_FALLING.get(), MapleTreeLeavesFallingParticle::provider);
	}
}
