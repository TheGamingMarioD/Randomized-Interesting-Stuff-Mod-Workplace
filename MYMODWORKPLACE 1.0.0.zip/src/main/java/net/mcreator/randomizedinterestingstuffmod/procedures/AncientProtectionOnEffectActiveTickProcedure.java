package net.mcreator.randomizedinterestingstuffmod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModMobEffects;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;

public class AncientProtectionOnEffectActiveTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_HELMET
				.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_CHESTPLATE
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_LEGGINGS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_BOOTS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY)
								.getItem()) {
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 2)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 2)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 2)));
		} else if (RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_CHESTPLATE
				.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
						.getItem()) {
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 1)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 1)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1,
						(int) ((entity instanceof LivingEntity _livEnt
								&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get())
										? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get()).getAmplifier()
										: 0)
								* 1)));
		}
	}
}
