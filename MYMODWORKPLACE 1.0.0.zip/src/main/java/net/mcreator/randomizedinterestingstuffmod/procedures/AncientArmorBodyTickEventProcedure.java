package net.mcreator.randomizedinterestingstuffmod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModMobEffects;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;

public class AncientArmorBodyTickEventProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
				.getItem() == RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_CHESTPLATE.get()
				&& 6 > (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)) {
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(RandomizedInterestingStuffModModMobEffects.ANCIENT_PROTECTION.get(), 1, 0));
		}
	}
}
