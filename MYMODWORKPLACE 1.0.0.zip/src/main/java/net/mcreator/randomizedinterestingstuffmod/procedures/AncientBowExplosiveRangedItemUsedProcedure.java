package net.mcreator.randomizedinterestingstuffmod.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;

public class AncientBowExplosiveRangedItemUsedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player)
			_player.getCooldowns().addCooldown(RandomizedInterestingStuffModModItems.ANCIENT_BOW_EXPLOSIVE.get(), 15);
	}
}
