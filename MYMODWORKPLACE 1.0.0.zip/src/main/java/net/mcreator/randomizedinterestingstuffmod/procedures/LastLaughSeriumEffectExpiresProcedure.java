package net.mcreator.randomizedinterestingstuffmod.procedures;

public class LastLaughSeriumEffectExpiresProcedure {
	public static void execute() {
	}
}
