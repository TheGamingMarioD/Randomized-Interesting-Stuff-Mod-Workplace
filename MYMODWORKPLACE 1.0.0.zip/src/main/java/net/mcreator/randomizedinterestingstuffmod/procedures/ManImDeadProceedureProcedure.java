package net.mcreator.randomizedinterestingstuffmod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModMobEffects;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;
import net.mcreator.randomizedinterestingstuffmod.RandomizedInterestingStuffModMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class ManImDeadProceedureProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_HELMET
				.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_CHESTPLATE
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_LEGGINGS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_BOOTS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY)
								.getItem()) {
			if (entity instanceof LivingEntity _livEnt
					? _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
					: false) {
				RandomizedInterestingStuffModMod.queueServerWork(10, () -> {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entity.getX()), (entity.getY()), (entity.getZ()),
								(float) ((entity instanceof LivingEntity _livEnt
										&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
												? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get()).getAmplifier()
												: 0)
										* 10),
								Explosion.BlockInteraction.NONE);
				});
			} else {
				RandomizedInterestingStuffModMod.queueServerWork(10, () -> {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entity.getX()), (entity.getY()), (entity.getZ()), 6, Explosion.BlockInteraction.NONE);
				});
			}
		} else if (RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_LEGGINGS
				.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)
						.getItem()) {
			if (entity instanceof LivingEntity _livEnt
					? _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
					: false) {
				RandomizedInterestingStuffModMod.queueServerWork(10, () -> {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entity.getX()), (entity.getY()), (entity.getZ()),
								(float) ((entity instanceof LivingEntity _livEnt
										&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
												? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get()).getAmplifier()
												: 0)
										* 8),
								Explosion.BlockInteraction.NONE);
				});
			} else {
				RandomizedInterestingStuffModMod.queueServerWork(10, () -> {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entity.getX()), (entity.getY()), (entity.getZ()), 6, Explosion.BlockInteraction.NONE);
				});
			}
		} else if (entity instanceof LivingEntity _livEnt
				? _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
				: false) {
			RandomizedInterestingStuffModMod.queueServerWork(10, () -> {
				if (world instanceof Level _level && !_level.isClientSide())
					_level.explode(null, (entity.getX()), (entity.getY()), (entity.getZ()),
							(float) ((entity instanceof LivingEntity _livEnt
									&& _livEnt.hasEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get())
											? _livEnt.getEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get()).getAmplifier()
											: 0)
									* 6),
							Explosion.BlockInteraction.NONE);
			});
		}
	}
}
