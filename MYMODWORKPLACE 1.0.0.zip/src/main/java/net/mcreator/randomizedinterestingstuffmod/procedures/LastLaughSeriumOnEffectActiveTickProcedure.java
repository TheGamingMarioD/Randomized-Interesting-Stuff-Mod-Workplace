package net.mcreator.randomizedinterestingstuffmod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModMobEffects;
import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModItems;

public class LastLaughSeriumOnEffectActiveTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		Entity LastLaughSeriumLvl = null;
		if (!entity.isAlive() && RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_HELMET
				.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_CHESTPLATE
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_LEGGINGS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)
								.getItem()
				&& RandomizedInterestingStuffModModItems.ANCIENT_ARMOR_BOOTS
						.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY)
								.getItem()) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get());
		} else if (!entity.isAlive()) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(RandomizedInterestingStuffModModMobEffects.LAST_LAUGH_SERIUM.get());
		}
	}
}
