
package net.mcreator.randomizedinterestingstuffmod.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.material.MaterialColor;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import net.mcreator.randomizedinterestingstuffmod.init.RandomizedInterestingStuffModModFluids;

public class DeepDarkMudBlock extends LiquidBlock {
	public DeepDarkMudBlock() {
		super(() -> RandomizedInterestingStuffModModFluids.DEEP_DARK_MUD.get(), BlockBehaviour.Properties
				.of(Material.WATER, MaterialColor.COLOR_BLACK).strength(100f).lightLevel(s -> 1).noCollission().noLootTable());
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
